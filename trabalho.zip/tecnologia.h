#ifndef TECNOLOGIA_H
#define TECNOLOGIA_H

#define TAM_STRING_VARIAVEL 55  // Defina o tamanho apropriado

typedef struct Tecnologia {
    char nome[TAM_STRING_VARIAVEL];
    int contagem;
} Tecnologia;

#endif
