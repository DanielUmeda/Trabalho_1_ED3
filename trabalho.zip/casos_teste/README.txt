Arquivo zip gerado em: 14/11/2023 16:01:22 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho Prático Introdutório