#include "tecnologia.h"

// Implementação das funções relacionadas a tecnologia, se necessário
