#ifndef FUNCOES_H
#define FUNCOES_H

#include <stdio.h>

void readline(char* string);
void binarioNaTela(char *nomeArquivoBinario); 
void scan_quote_string(char *str);

#endif